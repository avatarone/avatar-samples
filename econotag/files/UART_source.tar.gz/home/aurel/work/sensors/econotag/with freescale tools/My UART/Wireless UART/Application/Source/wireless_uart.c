/************************************************************************************
* Wireless Uart Main 
*
* (c) Copyright 2006, Freescale, Inc.  All rights reserved.
*
* No part of this document must be reproduced in any form - including copied,
* transcribed, printed or by any electronic means - without specific written
* permission from Freescale.
*
* Last Inspected:
* Last Tested:
************************************************************************************/


#include "../Utilities/UartUtil.h"
#include "../Configure/app_config.h"

#include "../../PLM/LibInterface/Crm.h"
#include "../../PLM/LibInterface/Timer.h"
#include "../../PLM/LibInterface/Interrupt.h"
#include "../../PLM/Interface/RF_Config.h"
#include "../../PLM/Interface/PlatformInit.h"
#include "../../SMAC/Configure/options_config.h"
#include "../../SMAC/Configure/security_config.h"
#include "../../SMAC/Drivers/Configure/board_config.h"
#include "../../SMAC/Drivers/Interface/ghdr/maca.h"
#include "../../SMAC/Drivers/Interface/Delay.h"
#include "../../SMAC/Drivers/Interface/MacaInterrupt.h"
#include "../../SMAC/Interface/GlobalDefs.h"
#include "../../SMAC/Interface/TransceiverConfigMngmnt.h"
#include "../../SMAC/Interface/TransceiverPowerMngmnt.h"
#include "../../SMAC/Interface/WirelessLinkMngmt.h"
#include "../../SMAC/Interface/SecurityMngmnt.h"
#include "../../SMAC/Interface/TransceiverPowerMngmnt.h"
#include "../Utilities/Leds.h"
#include "../Utilities/Keyboard.h"

#if OTAP_ENABLED == TRUE
#include "../Otap/Otap.h"
#endif


/************************************************************************************
*************************************************************************************
* Private macros
*************************************************************************************
************************************************************************************/
#define WIRELESS_UART_CHANN CHANNEL_NUMBER

typedef union bytes_2_short_tag {
  uint16_t u16Short;
  struct{
    uint8_t Byte0;
    uint8_t Byte1;
  }bytes;
}bytes_2_short_t;

/************************************************************************************
*************************************************************************************
* Private prototypes
*************************************************************************************
************************************************************************************/
static uint8_t str_end_pos(void);

/************************************************************************************
*************************************************************************************
* Private type definitions
*************************************************************************************
************************************************************************************/
#define RTCTimeout 0x000FFFFFF

#if SMAC_FEATURE_SECURITY == TRUE
 #define WAITING_LOOPS_FOR_ACK 0x0510
#else
 #define WAITING_LOOPS_FOR_ACK 0x0150
#endif


#define MAX_UART_SZ (12)
#define TX_SIZE  (smac_pdu_size(MAX_UART_SZ))

#if OTAP_ENABLED == TRUE
  #define RX_SIZE  OTAP_RX_SIZE
#else
  #define RX_SIZE (smac_pdu_size(31))
#endif

#if SMAC_FEATURE_SECURITY ==  TRUE
  ctr_value_t Ctr_Value = { CTR_0_INIT_VALUE, CTR_1_INIT_VALUE, \
                            CTR_2_INIT_VALUE, CTR_3_INIT_VALUE, };
  cipher_key_t CTR_Key = { KEY_0_INIT_VALUE, KEY_1_INIT_VALUE, \
                           KEY_2_INIT_VALUE, KEY_3_INIT_VALUE, };
#endif


/************************************************************************************
*************************************************************************************
* Private memory declarations
*************************************************************************************
************************************************************************************/

/************************************************************************************
*************************************************************************************
* Public functions
*************************************************************************************
************************************************************************************/
extern FuncReturn_t CrmInit(void);
extern FuncReturn_t TsmInit(void);
extern void ResetMaca(void);

void change_chann_dec_isr(void);
void change_chann_inc_isr(void);
void data_indication_execute(void);
void process_chann_change(void);
void wireless_uart_execute(void);
void wireless_uart_init(void);
void wireless_uart_rx_cb (void);

uint8_t cpy_uart_to_tx_msg (void);

/************************************************************************************
*************************************************************************************
* Public memory declarations
*************************************************************************************
************************************************************************************/

message_t TX_msg;
message_t RX_msg;
message_t ACK_msg;

uint16_t waiting_loops;
bytes_2_short_t seq_num;
bytes_2_short_t last_seq_num;

uint8_t ACK_data[smac_pdu_size(4)];
uint8_t data[TX_SIZE];
uint8_t dataRX[RX_SIZE];
uint8_t dataUart[MAX_UART_SZ];

uint8_t uart_buff_sz;
uint8_t num_retires;
channel_num_t gu8CurrentChannel;

bool_t am_i_waiting_4_ack;
bool_t gbDataIndicationFlag;

bool_t gbIncrementChannel;
bool_t gbDecrementChannel;

/************************************************************************************
* main function
*
* Executes the main function.
*
************************************************************************************/
void Main(void)
{
  wireless_uart_init();

  RX_msg.u8BufSize = RX_SIZE;
  MLMERXEnableRequest(&RX_msg, 0x00000100);

  for(;;)
  {
    (void)process_radio_msg();
    data_indication_execute();

#if OTAP_ENABLED == TRUE
    if(gbOtapExecute) 
    {           
      OTAP_execute();              
    }
    else
#endif  
    {
      wireless_uart_execute();
    }
  }
}


/************************************************************************************
* wireless_uart_execute function
*
* Executes the wireless uart application.
*
************************************************************************************/
void wireless_uart_execute(void)
{
  if( ( (MSG_TX_ACTION_COMPLETE_SUCCESS == TX_msg.u8Status.msg_state) ||
        (MSG_TX_ACTION_COMPLETE_FAIL == TX_msg.u8Status.msg_state))    &&
      ( TRUE == am_i_waiting_4_ack ) && ( 0 != num_retires )) {
      _t_dec(waiting_loops);
      if(0 == waiting_loops) {
        _t_dec(num_retires);
        MCPSDataRequest(&TX_msg);
        waiting_loops = WAITING_LOOPS_FOR_ACK;
      }
  }
  else{
    if(gUartReadStatusComplete_c == gu8SCIStatus)
    {
      if(0 != gu16SCINumOfBytes)
      {
        gu16SCINumOfBytes = 0;
        uart_buff_sz = cpy_uart_to_tx_msg();
        seq_num.u16Short++;
        TX_msg.pu8Buffer->u8Data[uart_buff_sz] = '\0';
        TX_msg.pu8Buffer->u8Data[uart_buff_sz+1] = (uint8_t)(seq_num.bytes.Byte0);
        TX_msg.pu8Buffer->u8Data[uart_buff_sz+2] = (uint8_t)(seq_num.bytes.Byte1);
#if SMAC_FEATURE_SECURITY ==  TRUE
        {
          uint8_t fill_counter;
          for(fill_counter=(uart_buff_sz+3); fill_counter<16; fill_counter++)
          {
             TX_msg.pu8Buffer->u8Data[fill_counter] = '\0';
          }
          TX_msg.u8BufSize = 16;

          (void)CipherMsgU8 (&(TX_msg.pu8Buffer->u8Data[0]), 
                                 (TX_msg.u8BufSize));
        }
#else
        TX_msg.u8BufSize = uart_buff_sz + 3;
#endif
  
        MCPSDataRequest(&TX_msg);
        waiting_loops = WAITING_LOOPS_FOR_ACK;
        num_retires = 3;
        am_i_waiting_4_ack = TRUE;
      }
    }
  }
  if( ( (MSG_RX_ACTION_COMPLETE_SUCCESS == RX_msg.u8Status.msg_state) ||
        (MSG_RX_ACTION_COMPLETE_FAIL == RX_msg.u8Status.msg_state)    ||
        (MSG_RX_TIMEOUT_FAIL == RX_msg.u8Status.msg_state)) && 
      (FALSE == gbDataIndicationFlag) )
  {
      RX_msg.u8BufSize = RX_SIZE;         
      MLMERXEnableRequest(&RX_msg, 0x00000100);
  }

  process_chann_change();

}

/************************************************************************************
* cpy_uart_to_tx_msg function
*
* This function copies the uart buffer to the message for tranmiting it over the air.
*
************************************************************************************/
uint8_t cpy_uart_to_tx_msg (void)
{
  uint8_t i;
  i=0;
  while(UartGetByteFromRxBuffer(gUart_PortDefault_d, &(TX_msg.pu8Buffer->u8Data[i])) && (i<=MAX_UART_SZ))
  {
    i++;
  }
  return i;
}

/************************************************************************************
* wireless_uart_init function
*
* This function inits variables, buffers, interrupts, etc. to init the wireless uart
* application.
*
************************************************************************************/
void wireless_uart_init(void)
{
  am_i_waiting_4_ack = FALSE;
  gbDataIndicationFlag = FALSE;
  gbIncrementChannel = FALSE;
  gbDecrementChannel = FALSE;
  gu8CurrentChannel = WIRELESS_UART_CHANN;

  seq_num.u16Short = 0;

  MSG_INIT(TX_msg, &data, NULL);
  MSG_INIT(ACK_msg, &ACK_data, NULL);
  MSG_INIT(RX_msg, &dataRX, wireless_uart_rx_cb);
  RX_msg.u8BufSize = 10;

  ITC_Init();

  IntAssignHandler(gMacaInt_c, MACA_Interrupt);
  ITC_SetPriority(gMacaInt_c, gItcFastPriority_c); // gItcNormalPriority_c
  ITC_EnableInterrupt(gMacaInt_c);

  IntAssignHandler(gCrmInt_c, (IntHandlerFunc_t)CRM_Isr);
  ITC_SetPriority(gCrmInt_c, gItcNormalPriority_c);
  ITC_EnableInterrupt(gCrmInt_c);

  CRM_RegisterISR(gCrmKB4WuEvent_c,  change_chann_dec_isr);
  CRM_RegisterISR(gCrmKB5WuEvent_c,  change_chann_inc_isr);

  IntDisableAll();

  ResetMaca();
  MLMERadioInit();
  PlatformPortInit();
  MLMESetChannelRequest(gu8CurrentChannel);

  IntEnableAll();
  
  KbGpioInit();
  Uart_Init(dataUart, MAX_UART_SZ);
  LED_Init();

  MLMESetWakeupSource(gExtWuKBI4En_c | gExtWuKBI5En_c , 0x00, 0x0F);

  Uart_Print("\n\rWireless Typematic Demo.\n\r");

  (void)MLMEPAOutputAdjust(gDefaultPowerLevel_c);

#if SMAC_FEATURE_SECURITY ==  TRUE
  (void)CipherEngineInit();
  (void)CipherConfigure(AES_DEFAULT_MODE, &CTR_Key, &Ctr_Value);
#endif

  DelayMs(500);
  MLMESetChannelRequest(gu8CurrentChannel);

  LED_SetHex(gu8CurrentChannel);

#if OTAP_ENABLED == TRUE
  OTAP_Init(&RX_msg);
  gbOtapExecute = OTAP_ENABLED;  
#endif  

}

/************************************************************************************
* wireless_uart_rx_cb function
*
* This function is called from MACA interrupt when a data indication event occurs.
*
************************************************************************************/
void wireless_uart_rx_cb (void)
{
  if(TRUE == gRadioEvntFlags.Bits.data_indication_flag)
  {
    gRadioEvntFlags.Bits.data_indication_flag = FALSE;
    gbDataIndicationFlag = TRUE;
  }
  else
  {
    /* Do nothing */
  }
}


/************************************************************************************
* data_indication_execute function
*
* This function executes the actions that must be performed when an message is received.
*
************************************************************************************/
void data_indication_execute(void)
{
  uint8_t buff[RX_msg.u8BufSize];
  bool_t bToPrint;
  uint8_t i;
  uint8_t u8Pos;
  bytes_2_short_t tmp;
  bToPrint = TRUE;

  if( (TRUE == gbDataIndicationFlag) && 
      (MSG_RX_ACTION_COMPLETE_SUCCESS == RX_msg.u8Status.msg_state))
  {
    gbDataIndicationFlag = FALSE;

#if OTAP_ENABLED == TRUE
    OTAP_data_indication_execute();   
    if(!gbOtapExecute)
#endif
    {
  #if SMAC_FEATURE_SECURITY ==  TRUE
      (void)DecipherMsgU8(&(RX_msg.pu8Buffer->u8Data[1]), (RX_msg.u8BufSize));
  #endif
      i = 1;
      if(('A' == RX_msg.pu8Buffer->u8Data[1]) &&
         ('C' == RX_msg.pu8Buffer->u8Data[2]) &&
         ('K' == RX_msg.pu8Buffer->u8Data[3]))
      {
        am_i_waiting_4_ack = FALSE;
      }
      else
      {
        ACK_msg.pu8Buffer->u8Data[0] = 'A';
        ACK_msg.pu8Buffer->u8Data[1] = 'C';
        ACK_msg.pu8Buffer->u8Data[2] = 'K';

  #if SMAC_FEATURE_SECURITY ==  TRUE
        {
          uint8_t fill_counter;
          for(fill_counter=3; fill_counter<16; fill_counter++)
          {
             ACK_msg.pu8Buffer->u8Data[fill_counter] = '\0';
          }
          ACK_msg.u8BufSize = 16;
          (void)CipherMsgU8(&(ACK_msg.pu8Buffer->u8Data[0]), (ACK_msg.u8BufSize));
        }
  #else
        ACK_msg.pu8Buffer->u8Data[3] = '\0';
        ACK_msg.u8BufSize = 4;
  #endif

        MCPSDataRequest(&ACK_msg);

        u8Pos = str_end_pos();
        i=0;
        while (i<u8Pos){
        	buff[i]=RX_msg.pu8Buffer->u8Data[i];
        	i++;
        }

        if((RX_msg.u8BufSize) > (str_end_pos())){
          tmp.bytes.Byte0 = RX_msg.pu8Buffer->u8Data[u8Pos+1];
          tmp.bytes.Byte1 = RX_msg.pu8Buffer->u8Data[u8Pos+2];
          if(tmp.u16Short != last_seq_num.u16Short){
            last_seq_num.u16Short = tmp.u16Short;
          } else {
            bToPrint = FALSE;
          }
        }

        if(TRUE == bToPrint){
          while(i< u8Pos){
            Uart_Tx(&(buff[i]), 1);
            i++;
          }
        }

      }
    }
  }
}



/************************************************************************************
* process_chann_change function
*
* This function check it a channel increase or decrease has been requested by pressing
* SW2 or SW1.
*
************************************************************************************/
void process_chann_change(void)
{
  channel_num_t tmpChann;
  FuncReturn_t tmpChange;
  uint8_t u8SafeTimeOut;
  
  tmpChann = gu8CurrentChannel;
 
  tmpChange = gFail_c;
  u8SafeTimeOut = 0xFF;

  if(TRUE == gbDecrementChannel)
  {
    gbDecrementChannel = FALSE;
    do{
      u8SafeTimeOut++;
      if(CHANNEL11 == tmpChann)
      {
        tmpChann = CHANNEL26;
      } 
      else
      {
        tmpChann--;
      }
  
      if(tmpChann != gu8CurrentChannel)
      {
        gu8CurrentChannel = tmpChann;
        tmpChange = MLMESetChannelRequest(gu8CurrentChannel);
        LED_SetHex(gu8CurrentChannel);
      }
    }while((gSuccess_c != tmpChange) && (gNumChannNotOnPALock_c >= u8SafeTimeOut));
  }

  if(TRUE == gbIncrementChannel)
  {
    gbIncrementChannel = FALSE;
    do{
      u8SafeTimeOut++;
      if(CHANNEL26 <= tmpChann)
      {
        tmpChann = CHANNEL11;
      } 
      else
      {
        tmpChann++;
      }
  
      if(tmpChann != gu8CurrentChannel)
      {
        gu8CurrentChannel = tmpChann;
        tmpChange = MLMESetChannelRequest(gu8CurrentChannel);
        LED_SetHex(gu8CurrentChannel);
      }
    }while((gSuccess_c != tmpChange) && (gNumChannNotOnPALock_c >= u8SafeTimeOut));
  }

}

/************************************************************************************
* change_chann_dec_isr function
*
*
************************************************************************************/
void change_chann_dec_isr(void)
{
  gbDecrementChannel = TRUE;
}

/************************************************************************************
* change_chann_inc_isr function
*
*
************************************************************************************/
void change_chann_inc_isr(void)
{
  gbIncrementChannel = TRUE;
}

/************************************************************************************
*************************************************************************************
* Private functions
*************************************************************************************
************************************************************************************/

/************************************************************************************
* str_end_pos function
*
* This function looks for an end of string on the received message.
*
************************************************************************************/
static uint8_t str_end_pos(void)
{
  uint8_t u8Count;
  uint8_t * u8pTmp;
  u8Count = 0;
  u8pTmp = &(RX_msg.pu8Buffer->u8Data[0]);
  while('\0' != (*u8pTmp)){
    u8Count++;
    u8pTmp++;
  }
  return u8Count;
}

/************************************************************************************
*************************************************************************************
* Private Debug stuff
*************************************************************************************
************************************************************************************/


